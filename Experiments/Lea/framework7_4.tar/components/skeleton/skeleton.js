export default {
  name: 'skeleton',
};
